=== Contact Form 7 Database ===
Contributors: ninjateam
Tags: 	contact, contact form, contact form 7, database, form, forms, save data contact form 7
Requires at least: 3.5
Tested up to: 5.0.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Allows you save all submitted from contact form 7 to database

== Description ==
Are you using contact Form 7? This is a nice plugin for you!

Contact Form 7 Database is a plugin for WordPress allows you save all submitted from contact form 7 to database and display in Contact > Database menu, and you can view it anytime. This plugin have powerful options and I’m sure you will like it.

Live Demo: http://demo.ninjateam.org/contact-form-7-database

Backend: http://demo.ninjateam.org/contact-form-7-database/admin (demo / demo) 

FEATURED

	Save submitted from Contact Form 7 to database
	Easy to change tag name
	Drag and drop to sort columns
	Enable or disable columns
	Export submitted data to CSV
	Export any columns data to CSV
	Easy to export email data to CSV for marketing
	Display submitted data for each form
	Easy to use
	And more…


== Installation ==
Manual installation is easy and takes fewer than one minute.

1. Download the plugin from WordPress.org, unpack it and upload the [Contact Form 7 Database] folder to your wp-content/plugins/ directory.
2. Activate the plugin through the ‘Plugins‘ menu in WordPress.
3. Go to your main WordPress menu > Contact form 7 > Database, and configure the basic options (fan page URL, color, language, where to display, etc)

You’re done. Enjoy.

== Screenshots ==
1. screenshot-1.jpg
2. screenshot-2.jpg
3. screenshot-3.jpg

== Changelog ==
==1.0==
- Version 1.0 Initial Release